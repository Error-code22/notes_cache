globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/sWQn19Ukow7BryJPxGZg4/_buildManifest.js",
    "static/sWQn19Ukow7BryJPxGZg4/_ssgManifest.js",
    "static/sWQn19Ukow7BryJPxGZg4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0iqrmd01_xey-.js",
    "static/chunks/1hy1hde_5mm8b.js",
    "static/chunks/1wmh802wjg0q4.js",
    "static/chunks/turbopack-2l5brq26ykja3.js"
  ]
};
