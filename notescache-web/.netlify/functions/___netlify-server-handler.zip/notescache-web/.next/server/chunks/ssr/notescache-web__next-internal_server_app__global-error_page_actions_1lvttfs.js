module.exports=[8165,(a,b,c)=>{}];

//# sourceMappingURL=notescache-web__next-internal_server_app__global-error_page_actions_1lvttfs.js.map