module.exports=[37458,(a,b,c)=>{}];

//# sourceMappingURL=notescache-web__next-internal_server_app_page_actions_0d351l5.js.map