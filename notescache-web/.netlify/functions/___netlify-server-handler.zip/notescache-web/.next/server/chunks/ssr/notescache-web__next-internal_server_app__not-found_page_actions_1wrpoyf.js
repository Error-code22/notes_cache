module.exports=[94496,(a,b,c)=>{}];

//# sourceMappingURL=notescache-web__next-internal_server_app__not-found_page_actions_1wrpoyf.js.map