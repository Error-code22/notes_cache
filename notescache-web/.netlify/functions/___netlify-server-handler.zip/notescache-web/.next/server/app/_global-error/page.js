var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1t-r36-._.js")
R.c("server/chunks/ssr/0u2u_next_dist_esm_build_templates_app-page_02zmqw7.js")
R.c("server/chunks/ssr/[root-of-the-server]__1wai5ic._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1zuph39._.js")
R.c("server/chunks/ssr/0u2u_next_dist_client_components_builtin_global-error_0sa_py2.js")
R.c("server/chunks/ssr/notescache-web__next-internal_server_app__global-error_page_actions_1lvttfs.js")
R.m(59663)
module.exports=R.m(59663).exports
